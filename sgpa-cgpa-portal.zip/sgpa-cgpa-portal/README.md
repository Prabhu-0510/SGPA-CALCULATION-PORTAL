# ARM College GPA Portal

A modern, comprehensive SGPA and CGPA calculator for ARM College of Engineering and Technology.

## Features
- **SGPA Calculator**: Calculate semester GPA with real-time feedback.
- **CGPA Calculator**: Weighted CGPA calculation across multiple semesters.
- **Percentage Converter**: Convert CGPA and Grade Points to percentage.
- **PDF Download**: Download professional PDF reports of your calculations.
- **History**: Save and view past calculations.

## How to Run

### Option 1: Full Capability (Recommended)
Running with the local server allows you to **Save Calculations** to your history.

1.  Open a terminal in the project folder.
2.  Navigate to the server directory:
    ```bash
    cd server
    ```
3.  Install dependencies (first time only):
    ```bash
    npm install
    ```
4.  Start the server:
    ```bash
    npm start
    ```
5.  Open your browser and go to: [http://localhost:3000](http://localhost:3000)

### Option 2: Offline Mode (Basic)
You can run the calculator without the server, but **History/Saving** will not work.

1.  Simply double-click `index.html` in the project folder.
2.  Or open `index.html` with your web browser.
3.  **Note**: PDF downloads should still work if you have an internet connection (for loading the PDF library).

## Troubleshooting

-   **ERR_FILE_NOT_FOUND**: This typically means you moved the project folder or are trying to open a file that was deleted. Ensure `index.html`, `css/`, and `js/` folders are in the same place.
-   **PDF Not Downloading**: Ensure you have an internet connection to load the PDF generator library.
-   **Failed to Fetch / Save**: Ensure the server is running (`npm start`) if you want to save calculations.

## Project Structure
-   `/index.html` - Main application file
-   `/css/style.css` - Styling and animations
-   `/js/script.js` - Calculator logic and interaction
-   `/server/server.js` - Backend for saving history
