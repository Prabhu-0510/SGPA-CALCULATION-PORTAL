const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');
const fs = require('fs-extra');

const DATAFILE = path.join(__dirname, 'calculations.json');
fs.ensureFileSync(DATAFILE);

let app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, '..')));

// GET calculations
app.get('/api/calculations', async (req, res) => {
  try {
    const data = await fs.readJson(DATAFILE).catch(() => []);
    // optional filtering: ?weekStart=YYYY-MM-DD or ?lastDays=n
    const { weekStart, lastDays } = req.query;
    if (weekStart) {
      const start = new Date(weekStart);
      const end = new Date(start.getTime() + 7 * 24 * 60 * 60 * 1000);
      const filtered = data.filter((d) => {
        const t = new Date(d.timestamp);
        return t >= start && t < end;
      });
      if (!filtered || filtered.length === 0) {
        return res.json({ message: 'No data found for this week', data: [] });
      }
      return res.json(filtered);
    }
    if (lastDays) {
      const days = parseInt(lastDays, 10) || 7;
      const start = new Date(Date.now() - days * 24 * 60 * 60 * 1000);
      const filtered = data.filter((d) => new Date(d.timestamp) >= start);
      if (!filtered || filtered.length === 0) {
        return res.json({ message: `No data found for last ${days} days`, data: [] });
      }
      return res.json(filtered);
    }
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: 'Could not read data' });
  }
});

// POST calculation
app.post('/api/calculations', async (req, res) => {
  try {
    const payload = req.body;
    if (!payload || !payload.type) return res.status(400).json({ error: 'invalid body' });
    const data = await fs.readJson(DATAFILE).catch(() => []);
    data.push(payload);
    await fs.writeJson(DATAFILE, data, { spaces: 2 });
    res.json({ ok: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not save data' });
  }
});

// AI Chatbot Backend
app.post('/api/chat', async (req, res) => {
  try {
    const { message } = req.body;
    if (!message) return res.status(400).json({ reply: "I didn't receive a message." });

    const lowerMsg = message.toLowerCase();
    let reply = "I'm not sure how to help with that. Try asking about your history or to calculate SGPA.";

    // 1. History Analysis
    if (lowerMsg.includes("history") || lowerMsg.includes("last") || lowerMsg.includes("analyze")) {
      const data = await fs.readJson(DATAFILE).catch(() => []);
      if (data.length === 0) {
        reply = "I don't see any saved calculations in the database yet. Try calculating and saving some grades first!";
      } else {
        const last = data[data.length - 1];
        reply = `I found ${data.length} saved calculations. Your most recent activity was a ${last.type.toUpperCase()} calculation on ${new Date(last.timestamp).toLocaleDateString()}. \n\nResult: ${JSON.stringify(last.payload.result)}`;

        if (lowerMsg.includes("analyze")) {
          // Simple analysis
          const sgpas = data.filter(d => d.type === 'sgpa').map(d => parseFloat(d.payload.sgpa || 0));
          if (sgpas.length > 0) {
            const max = Math.max(...sgpas);
            const avg = (sgpas.reduce((a, b) => a + b, 0) / sgpas.length).toFixed(2);
            reply += `\n\nAnalysis: You have calculated SGPA ${sgpas.length} times. Your best SGPA is ${max} and your average is ${avg}.`;
          }
        }
      }
    }
    // 2. Calculation Logic (Natural Language Processing Simulation)
    else if (lowerMsg.includes("calculate") || lowerMsg.includes("calc")) {
      // "calc sgpa credits 3,4 grades 8,9"
      if (lowerMsg.includes("sgpa")) {
        const numbers = message.match(/\d+(\.\d+)?/g);
        if (numbers && numbers.length >= 2 && numbers.length % 2 === 0) {
          let totalPoints = 0;
          let totalCredits = 0;
          // Assume pairs of (Credit, Grade) or (Grade, Credit). Let's standardize on Credit first then Grade for pairs, or just sum products if length matches.
          // Heuristic: Split into two groups if explicit, otherwise assume pairs.
          // Let's assume the user provides lists: "credits: 3, 4" "grades: 9, 8"

          // Simple Pair Mode for "calc 3 9 4 8" (3*9 + 4*8)
          for (let i = 0; i < numbers.length; i += 2) {
            const val1 = parseFloat(numbers[i]);
            const val2 = parseFloat(numbers[i + 1]);
            // Credits usually 1-4, Grades 0-10.
            // If one is > 5 it's likely grade.
            let credit = val1 <= 5 ? val1 : val2;
            let grade = val1 > 5 ? val1 : val2;

            totalPoints += credit * grade;
            totalCredits += credit;
          }
          const result = (totalPoints / totalCredits).toFixed(2);
          reply = `Based on the numbers provided, your SGPA is approximately **${result}**. (Calculated from ${numbers.length / 2} subjects).`;
        } else {
          reply = "To calculate SGPA here, please provide pairs of credits and grades. Example: 'Calculate SGPA for 3 credits 8 grade, 4 credits 9 grade'.";
        }
      }
    }
    // 3. Knowledge Base
    else if (lowerMsg.includes("hello") || lowerMsg.includes("hi")) {
      reply = "Hello! I am your AI Academic Assistant. I can access your calculation history, analyze your performance, or help you calculate grades instantly.";
    }
    else if (lowerMsg.includes("formula")) {
      reply = "SGPA = Σ(Credit × Grade Point) / Σ(Total Credits)\nCGPA = Σ(SGPA × Credits) / Σ(Total Credits)\nPercentage = CGPA × 10";
    }

    res.json({ reply });
  } catch (err) {
    console.error("AI Error:", err);
    res.status(500).json({ reply: "I encountered an internal error while processing your request." });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log('Server running on port', PORT));
